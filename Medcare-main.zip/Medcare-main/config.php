<?php

$conn = mysqli_connect('localhost','id19730667_root','Medcareroot@123','id19730667_user_db');

?>